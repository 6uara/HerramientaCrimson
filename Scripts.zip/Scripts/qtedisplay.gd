# QTEDisplay.gd
# Control que dibuja el QTE sobre el sprite del enemigo.
# Adjuntarlo a un Control de pantalla completa (CanvasLayer recomendado).
# process_mode: Always
extends Control

# ──────────────────────────────────────────────
#  Señales
# ──────────────────────────────────────────────
signal attack_resolved(shots: Array)  # [{point, damage, zone, hit}]

# ──────────────────────────────────────────────
#  Exports — asignar en Inspector
# ──────────────────────────────────────────────
@export var qte_controller: Node  # Asignar nodo con QTEController.gd
@export var confirm_button: Button
@export var sprite_node: TextureRect   # TextureRect con el sprite del enemigo

# ──────────────────────────────────────────────
#  Placeholder — se usa si no hay sprite real cargado
# ──────────────────────────────────────────────
const PLACEHOLDER_COLOR := Color(0.35, 0.35, 0.45)

# ──────────────────────────────────────────────
#  Zonas de daño (porcentajes verticales, iguales para todos)
# ──────────────────────────────────────────────
const ZONE_HEAD_END   := 0.20   # 0–20% = cabeza
const ZONE_TORSO_END  := 0.60   # 20–60% = torso
								 # 60–100% = piernas

const ZONE_MULTIPLIERS := {
	"Cabeza":  2.0,
	"Torso":   1.0,
	"Piernas": 0.6,
}

const COLOR_HEAD_TINT   := Color(1.0, 0.3, 0.3, 0.25)
const COLOR_TORSO_TINT  := Color(0.3, 0.6, 1.0, 0.25)
const COLOR_LEGS_TINT   := Color(0.3, 1.0, 0.4, 0.25)
const COLOR_LINE_V      := Color(1.0, 0.9, 0.2, 0.9)
const COLOR_LINE_H      := Color(0.2, 0.95, 1.0, 0.9)
const COLOR_HIT         := Color(1.0, 0.4, 0.1)
const COLOR_MISS        := Color(0.55, 0.55, 0.55)
const COLOR_BG          := Color(0.05, 0.05, 0.08, 0.92)
const SPRITE_DISPLAY_SIZE := Vector2(200.0, 350.0)
# ──────────────────────────────────────────────
#  Estado interno
# ──────────────────────────────────────────────
var _sprite_rect: Rect2          
var _line_v: float = 0.0         
var _line_h: float = 0.0
var _phase: String = "idle"      

var _shots_pending: int   = 0
var _bullet_damage: float = 0.0
var _player: Object = null
var _elipse: Object = null
var _resolved: Array = []        # shots ya calculados
var _current_enemy_data: Dictionary = {}  # datos del enemigo objetivo actual

# ──────────────────────────────────────────────
#  READY
# ──────────────────────────────────────────────
func _ready() -> void:
	qte_controller.axis_changed.connect(_on_axis_changed)
	qte_controller.qte_completed.connect(_on_qte_completed)
	confirm_button.pressed.connect(_on_confirm_pressed)
	hide()

# ──────────────────────────────────────────────
#  API pública
# ──────────────────────────────────────────────

# sprite_texture: la textura del enemigo actual (puede ser null → usa placeholder)
func _init_elipse() -> void:
	if _elipse == null:
		_elipse = load("res://ElipseCalculator.gd").new()

func set_enemy(enemy_data: Dictionary) -> void:
	_current_enemy_data = enemy_data

func start_qte(player: Object, bullets: int, sprite_texture: Texture2D = null) -> void:
	_player         = player
	_shots_pending  = bullets
	_bullet_damage  = player.damage
	_resolved.clear()
	_phase = "vertical"
	_line_v = 0.0
	_line_h = 1.0 if player.left_handed else 0.0

	# Cargar sprite o placeholder
	if sprite_texture != null:
		sprite_node.texture = sprite_texture
	else:
		sprite_node.texture = null   # _draw() dibuja el placeholder

	# Calcular rect del sprite centrado
	_update_sprite_rect()

	# Configurar elipse
	_init_elipse()
	_elipse.setup(
		player.elipse_h, player.elipse_k,
		player.elipse_r, player.elipse_a, player.elipse_b
	)

	show()
	queue_redraw()
	qte_controller.start(player)

func _update_sprite_rect() -> void:
	var sprite_size := Vector2(200.0, 350.0)  # Tamaño display del sprite/placeholder
	if sprite_node.texture != null:
		var tex := sprite_node.texture
		var scale := sprite_size.y / tex.get_height()
		sprite_size = tex.get_size() * scale

	var center := size / 2.0
	_sprite_rect = Rect2(center - sprite_size / 2.0, sprite_size)
	sprite_node.position = _sprite_rect.position
	sprite_node.size     = _sprite_rect.size

# ──────────────────────────────────────────────
#  PROCESO
# ──────────────────────────────────────────────
func _process(delta: float) -> void:
	if not visible or not qte_controller.is_active():
		return
	qte_controller.tick(delta)
	queue_redraw()

# ──────────────────────────────────────────────
#  SEÑALES DEL CONTROLLER
# ──────────────────────────────────────────────
func _on_axis_changed(axis: String, value: float) -> void:
	if axis == "vertical":
		_line_v = value
		_phase  = "vertical"
	else:
		_line_h = value
		_phase  = "horizontal"
	queue_redraw()

func _on_confirm_pressed() -> void:
	qte_controller.register_input()

func _on_qte_completed(point: Vector2) -> void:
	_phase = "done"
	_line_h = point.x
	_line_v = point.y

	# Primer disparo — punto del QTE + chance de impacto
	var first := _resolve_shot(point, _player)
	_resolved.append(first)
	_elipse.set_anchor(point)

	# Disparos siguientes — elipse encadenada + chance
	for i in range(1, _shots_pending):
		var ep = _elipse.next_point().clamp(Vector2.ZERO, Vector2.ONE)
		_resolved.append(_resolve_shot(ep, _player))

	queue_redraw()

	await get_tree().create_timer(1.4).timeout
	hide()
	emit_signal("attack_resolved", _resolved)

# ──────────────────────────────────────────────
#  RESOLUCIÓN: zona + chance de impacto
# ──────────────────────────────────────────────
func _resolve_shot(point: Vector2, player: Object) -> Dictionary:
	# Zona según hitboxes del enemigo actual (definidas en HitboxEditor)
	var zone: String = "Torso"  # fallback
	var enemy_data: Dictionary = _current_enemy_data
	var hitboxes: Dictionary = enemy_data.get("hitboxes", {})

	if hitboxes.is_empty():
		# Sin hitboxes: porcentajes verticales por defecto
		if point.y <= ZONE_HEAD_END:
			zone = "Cabeza"
		elif point.y <= ZONE_TORSO_END:
			zone = "Torso"
		else:
			zone = "Piernas"
	else:
		var px := point.x * SPRITE_DISPLAY_SIZE.x
		var py := point.y * SPRITE_DISPLAY_SIZE.y
		for zd in hitboxes:
			var rect := Rect2(zd["x"], zd["y"], zd["w"], zd["h"])
			if rect.has_point(Vector2(px, py)):
				zone = zd["name"]
				break
	var chance := clampf(
		player.hit_chance_base - player.hit_chance_penalty * player.bullets_spent_total,
		0.0, 1.0
	)
	var hit := randf() <= chance
	# Obtener multiplicador de daño de la hitbox, o 1.0 si es zona por defecto
	var mult := _get_zone_mult(zone, _current_enemy_data.get("hitboxes", []))
	var damage := _bullet_damage * mult if hit else 0.0

	return {
		"point":  point,
		"zone":   zone,
		"hit":    hit,
		"chance": chance,
		"damage": damage,
		"mult":   mult,
	}

func _get_zone_mult(zone_name: String, hitboxes: Array) -> float:
	# Buscar multiplicador en la definición de hitboxes del enemigo
	for zd in hitboxes:
		if zd["name"] == zone_name:
			return float(zd.get("mult", 1.0))
	# Fallback para zonas por defecto sin hitboxes definidas
	match zone_name:
		"Cabeza":  return 2.0
		"Torso":   return 1.0
		"Piernas": return 0.6
	return 1.0

# ──────────────────────────────────────────────
#  DIBUJADO
# ──────────────────────────────────────────────
func _draw() -> void:
	_update_sprite_rect()
	var s := _sprite_rect
	var font := ThemeDB.fallback_font

	# Fondo oscuro pantalla completa
	draw_rect(Rect2(Vector2.ZERO, size), COLOR_BG)

	# Instrucción
	var instruction := ""
	match _phase:
		"vertical":   instruction = "↕  Presioná CONFIRMAR para fijar la mira vertical"
		"horizontal": instruction = "↔  Presioná CONFIRMAR para fijar la mira horizontal"
		"done":       instruction = "Impactos resueltos"
	draw_string(font, Vector2(s.position.x, s.position.y - 28),
		instruction, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color.WHITE)

	# Placeholder si no hay textura (el TextureRect dibuja la textura real si la tiene)
	if sprite_node.texture == null:
		draw_rect(s, PLACEHOLDER_COLOR)
		draw_string(font, s.position + Vector2(8, 20),
			"[sprite enemigo]", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(0.7, 0.7, 0.7))

	# Tints de zona sobre el sprite
	var head_h  := s.size.y * ZONE_HEAD_END
	var torso_h := s.size.y * (ZONE_TORSO_END - ZONE_HEAD_END)
	var legs_h  := s.size.y * (1.0 - ZONE_TORSO_END)
	draw_rect(Rect2(s.position,                              Vector2(s.size.x, head_h)),  COLOR_HEAD_TINT)
	draw_rect(Rect2(s.position + Vector2(0, head_h),         Vector2(s.size.x, torso_h)), COLOR_TORSO_TINT)
	draw_rect(Rect2(s.position + Vector2(0, head_h + torso_h), Vector2(s.size.x, legs_h)), COLOR_LEGS_TINT)

	# Etiquetas de zona
	draw_string(font, s.position + Vector2(4, head_h - 4),            "CABEZA ×2.0",  HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color.WHITE)
	draw_string(font, s.position + Vector2(4, head_h + torso_h - 4),  "TORSO ×1.0",  HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color.WHITE)
	draw_string(font, s.position + Vector2(4, s.size.y - 4),          "PIERNAS ×0.6",HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color.WHITE)

	# Borde del sprite
	draw_rect(s, Color.WHITE, false, 1.5)

	# Línea vertical (siempre visible una vez arranca)
	if _phase != "idle":
		var ly := s.position.y + _line_v * s.size.y
		draw_line(Vector2(s.position.x, ly), Vector2(s.position.x + s.size.x, ly),
			COLOR_LINE_V, 2.0)

	# Línea horizontal (visible desde fase horizontal)
	if _phase in ["horizontal", "done"]:
		var lx := s.position.x + _line_h * s.size.x
		draw_line(Vector2(lx, s.position.y), Vector2(lx, s.position.y + s.size.y),
			COLOR_LINE_H, 2.0)

	# Puntos de impacto
	for i in _resolved.size():
		var shot: Dictionary = _resolved[i]
		var pt: Vector2 = shot["point"]
		var px := s.position.x + pt.x * s.size.x
		var py := s.position.y + pt.y * s.size.y
		var col := COLOR_HIT if shot["hit"] else COLOR_MISS

		draw_circle(Vector2(px, py), 5.0, col)
		draw_circle(Vector2(px, py), 5.0, Color.WHITE, false, 1.5)

		var label := "%s  %.0f dmg" % [shot["zone"], shot["damage"]] if shot["hit"] \
			else "FALLO (%.0f%%)" % (shot["chance"] * 100)
		draw_string(font, Vector2(px + 8, py + 4), label,
			HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color.WHITE)

	# Chance actual en la esquina
	if _player and _phase != "done":
		var chance_now := clampf(
			_player.hit_chance_base - _player.hit_chance_penalty * _player.bullets_spent_total,
			0.0, 1.0
		)
		draw_string(font, Vector2(s.position.x, s.position.y + s.size.y + 20),
			"Chance de impacto: %.0f%%" % (chance_now * 100),
			HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.YELLOW)
