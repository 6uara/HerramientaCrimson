# HitboxEditor.gd
# Pantalla visual para editar zonas de daño por enemigo.
# Acceso: menú de pausa → "Editar Hitboxes"
# process_mode: Always
extends Control

# ──────────────────────────────────────────────
#  Señales
# ──────────────────────────────────────────────
signal close_requested

# ──────────────────────────────────────────────
#  Exports — asignar en Inspector
# ──────────────────────────────────────────────
@export var btn_close: Button
@export var btn_add_zone: Button
@export var btn_reset: Button
@export var enemy_tab_bar: TabBar        # TabBar con un tab por enemigo
@export var zone_list_container: VBoxContainer  # Panel lateral con lista de zonas
@export var multiplier_label: Label      # Muestra el mult de la zona seleccionada
@export var multiplier_spin: SpinBox     # Edita el mult de la zona seleccionada

# ──────────────────────────────────────────────
#  Constantes
# ──────────────────────────────────────────────
const SPRITE_SIZE    := Vector2(200.0, 350.0)
const HANDLE_RADIUS  := 6.0
const MIN_ZONE_SIZE  := 20.0   # px mínimos de ancho/alto

# Zonas por defecto al crear un enemigo nuevo o al resetear
const DEFAULT_ZONES := [
	{ "name": "Cabeza",  "rect": Rect2(50, 0,   100, 70),  "mult": 2.0, "color": Color(1.0, 0.3, 0.3, 0.5) },
	{ "name": "Torso",   "rect": Rect2(25, 70,  150, 140), "mult": 1.0, "color": Color(0.3, 0.6, 1.0, 0.5) },
	{ "name": "Piernas", "rect": Rect2(25, 210, 150, 140), "mult": 0.6, "color": Color(0.3, 1.0, 0.4, 0.5) },
]

const ZONE_PALETTE := [
	Color(1.0, 0.3, 0.3, 0.5),
	Color(0.3, 0.6, 1.0, 0.5),
	Color(0.3, 1.0, 0.4, 0.5),
	Color(1.0, 0.8, 0.2, 0.5),
	Color(0.8, 0.3, 1.0, 0.5),
	Color(1.0, 0.5, 0.1, 0.5),
]

# ──────────────────────────────────────────────
#  Estado
# ──────────────────────────────────────────────
var _current_enemy: int = 0

# Zonas del enemigo actual: Array de Dictionary
# { name, rect: Rect2 (px en SPRITE_SIZE), mult, color }
var _zones: Array = []

# Selección y drag
var _selected_zone: int  = -1
var _dragging:      bool = false
var _drag_mode:     String = ""   # "move" | "tl" | "tr" | "bl" | "br"
var _drag_start_mouse: Vector2
var _drag_start_rect:  Rect2

# Rect del sprite en coordenadas locales de este Control
var _sprite_rect: Rect2

# Panel de dibujo (hijo generado en _ready)
var _canvas: Control

# Botones de zona en el panel lateral
var _zone_buttons: Array = []

# ──────────────────────────────────────────────
#  READY
# ──────────────────────────────────────────────
func _draw() -> void:
	# Fondo oscuro sobre el combate
	draw_rect(Rect2(Vector2.ZERO, Vector2(280, get_viewport_rect().size.y)), Color(0.06, 0.06, 0.09, 1.0))

func _ready() -> void:
	# Ocupar toda la pantalla
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	btn_close.pressed.connect(func(): emit_signal("close_requested"))
	btn_add_zone.pressed.connect(_add_new_zone)
	btn_reset.pressed.connect(_reset_to_defaults)
	enemy_tab_bar.tab_changed.connect(_on_tab_changed)
	multiplier_spin.value_changed.connect(_on_mult_changed)

	_build_canvas()
	_build_enemy_tabs()
	hide()

# Llamado desde CombatSetup al abrir
func refresh() -> void:
	_build_enemy_tabs()
	_load_enemy(_current_enemy)

# ──────────────────────────────────────────────
#  Canvas de dibujo
# ──────────────────────────────────────────────
func _build_canvas() -> void:
	_canvas = Control.new()
	# El canvas ocupa solo la mitad derecha — el panel izquierdo (~280px) queda libre
	var vp := get_viewport_rect().size
	_canvas.position = Vector2(280, 0)
	_canvas.size     = Vector2(vp.x - 280, vp.y)
	_canvas.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(_canvas)
	# NO move_child — se agrega al final para quedar encima del fondo pero detrás de los controles UI
	_canvas.draw.connect(_on_canvas_draw)
	_canvas.gui_input.connect(_on_canvas_input)
	get_viewport().size_changed.connect(func():
		var v := get_viewport_rect().size
		_canvas.size = Vector2(v.x - 280, v.y)
		_canvas.queue_redraw()
	)

func _canvas_sprite_rect() -> Rect2:
	# Centrado dentro del área del canvas
	var cs := _canvas.size if _canvas.size.x > 10 else get_viewport_rect().size - Vector2(280, 0)
	var cx := cs.x * 0.5
	var cy := cs.y * 0.5
	return Rect2(Vector2(cx, cy) - SPRITE_SIZE / 2.0, SPRITE_SIZE)

# ──────────────────────────────────────────────
#  Tabs de enemigos
# ──────────────────────────────────────────────
func _build_enemy_tabs() -> void:
	# Limpiar tabs existentes
	while enemy_tab_bar.tab_count > 0:
		enemy_tab_bar.remove_tab(0)
	for d in GameData.enemy_data:
		enemy_tab_bar.add_tab(d["name"])
	_current_enemy = 0
	_load_enemy(0)

func _on_tab_changed(idx: int) -> void:
	_save_current_enemy()
	_current_enemy = idx
	_load_enemy(idx)

# ──────────────────────────────────────────────
#  Carga / guardado de zonas
# ──────────────────────────────────────────────
func _load_enemy(idx: int) -> void:
	var d: Dictionary = GameData.enemy_data[idx]
	if d.has("hitboxes") and not d["hitboxes"].is_empty():
		_zones = []
		for i in d["hitboxes"].size():
			var hz: Dictionary = d["hitboxes"][i]
			_zones.append({
				"name":  hz["name"],
				"rect":  Rect2(hz["x"], hz["y"], hz["w"], hz["h"]),
				"mult":  hz.get("mult", 1.0),
				"color": ZONE_PALETTE[i % ZONE_PALETTE.size()],
			})
	else:
		_reset_to_defaults(false)  # sin guardar

	_selected_zone = -1 if _zones.is_empty() else 0
	_refresh_zone_list()
	_refresh_mult_panel()
	_canvas.queue_redraw()

func _save_current_enemy() -> void:
	var hitboxes: Array = []
	for z in _zones:
		var r: Rect2 = z["rect"]
		hitboxes.append({
			"name": z["name"],
			"x": r.position.x, "y": r.position.y,
			"w": r.size.x,     "h": r.size.y,
			"mult": z["mult"],
		})
	GameData.enemy_data[_current_enemy]["hitboxes"] = hitboxes

# ──────────────────────────────────────────────
#  Gestión de zonas
# ──────────────────────────────────────────────
func _reset_to_defaults(save: bool = true) -> void:
	_zones = []
	for i in DEFAULT_ZONES.size():
		var dz: Dictionary = DEFAULT_ZONES[i]
		_zones.append({
			"name":  dz["name"],
			"rect":  dz["rect"],
			"mult":  dz["mult"],
			"color": dz["color"],
		})
	_selected_zone = 0
	_refresh_zone_list()
	_refresh_mult_panel()
	_canvas.queue_redraw()
	if save:
		_save_current_enemy()

func _add_new_zone() -> void:
	var idx := _zones.size()
	_zones.append({
		"name":  "Zona %d" % (idx + 1),
		"rect":  Rect2(50, 50, 100, 80),
		"mult":  1.0,
		"color": ZONE_PALETTE[idx % ZONE_PALETTE.size()],
	})
	_selected_zone = idx
	_refresh_zone_list()
	_refresh_mult_panel()
	_canvas.queue_redraw()

func _remove_zone(idx: int) -> void:
	_zones.remove_at(idx)
	_selected_zone = clamp(_selected_zone, -1, _zones.size() - 1)
	_refresh_zone_list()
	_refresh_mult_panel()
	_canvas.queue_redraw()

# ──────────────────────────────────────────────
#  Panel lateral — lista de zonas
# ──────────────────────────────────────────────
func _refresh_zone_list() -> void:
	for child in zone_list_container.get_children():
		zone_list_container.remove_child(child)
		child.free()
	_zone_buttons.clear()

	for i in _zones.size():
		var zone: Dictionary = _zones[i]
		var row := HBoxContainer.new()

		# Botón seleccionar (nombre de la zona)
		var btn_sel := Button.new()
		btn_sel.text = zone["name"]
		btn_sel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn_sel.toggle_mode = true
		btn_sel.button_pressed = (i == _selected_zone)
		btn_sel.add_theme_color_override(
			"font_color", zone["color"] + Color(0.4, 0.4, 0.4, 0.5)
		)
		var zi := i  # captura
		btn_sel.pressed.connect(func():
			_selected_zone = zi
			_refresh_zone_list()
			_refresh_mult_panel()
			_canvas.queue_redraw()
		)
		row.add_child(btn_sel)
		_zone_buttons.append(btn_sel)

		# Botón eliminar
		var btn_del := Button.new()
		btn_del.text = "✕"
		btn_del.custom_minimum_size.x = 28
		btn_del.pressed.connect(func(): _remove_zone(zi))
		row.add_child(btn_del)

		zone_list_container.add_child(row)

func _refresh_mult_panel() -> void:
	# Verificar que los nodos existen antes de acceder
	if not is_instance_valid(multiplier_label) or not is_instance_valid(multiplier_spin):
		return
	if _selected_zone < 0 or _selected_zone >= _zones.size():
		multiplier_label.text = "Zona: —"
		multiplier_spin.editable = false
		return
	var z: Dictionary = _zones[_selected_zone]
	multiplier_label.text = "Zona: %s" % z["name"]
	multiplier_spin.editable = true
	multiplier_spin.set_value_no_signal(z["mult"])

func _on_mult_changed(value: float) -> void:
	if _selected_zone >= 0 and _selected_zone < _zones.size():
		_zones[_selected_zone]["mult"] = value

# ──────────────────────────────────────────────
#  Dibujo del canvas
# ──────────────────────────────────────────────
func _on_canvas_draw() -> void:
	_sprite_rect = _canvas_sprite_rect()
	var s := _sprite_rect
	var font := ThemeDB.fallback_font

	# Fondo del área de canvas
	_canvas.draw_rect(Rect2(Vector2.ZERO, _canvas.size), Color(0.10, 0.10, 0.14, 1.0))

	# Título enemigo
	var enemy_name: String = GameData.enemy_data[_current_enemy]["name"]
	_canvas.draw_string(font, Vector2(s.position.x, s.position.y - 28),
		"Editando: %s" % enemy_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	_canvas.draw_string(font, Vector2(s.position.x, s.position.y - 10),
		"Drag = mover zona  |  Esquinas = redimensionar  |  Seleccioná una zona del panel",
		HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.7, 0.7, 0.7))

	# Sprite placeholder
	_canvas.draw_rect(s, Color(0.22, 0.22, 0.30))
	_canvas.draw_string(font, s.get_center() - Vector2(30, 0),
		"[sprite]", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.5, 0.5, 0.5))
	_canvas.draw_rect(s, Color(0.5, 0.5, 0.6), false, 1.0)

	# Zonas (de atrás hacia adelante; seleccionada encima)
	for i in _zones.size():
		if i == _selected_zone:
			continue
		_draw_zone(i, false)
	if _selected_zone >= 0 and _selected_zone < _zones.size():
		_draw_zone(_selected_zone, true)

func _draw_zone(idx: int, selected: bool) -> void:
	var zone: Dictionary = _zones[idx]
	var r := _zone_to_screen(zone["rect"])
	var col: Color = zone["color"]
	var font := ThemeDB.fallback_font

	# Fill
	_canvas.draw_rect(r, col)

	# Borde — más grueso si está seleccionado
	var border_col := Color.WHITE if selected else Color(0.8, 0.8, 0.8, 0.7)
	_canvas.draw_rect(r, border_col, false, 2.5 if selected else 1.0)

	# Etiqueta nombre + mult
	_canvas.draw_string(font, r.position + Vector2(4, 14),
		"%s  ×%.1f" % [zone["name"], zone["mult"]],
		HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color.WHITE)

	# Handles en esquinas (solo si seleccionada)
	if selected:
		for corner in _get_corner_positions(r):
			_canvas.draw_circle(corner, HANDLE_RADIUS, Color.WHITE)
			_canvas.draw_circle(corner, HANDLE_RADIUS, Color(0.2, 0.2, 0.2), false, 1.5)

# ──────────────────────────────────────────────
#  Input — drag & drop
# ──────────────────────────────────────────────
func _on_canvas_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				_try_start_drag(mb.position)
			else:
				if _dragging:
					_save_current_enemy()
				_dragging = false
				_drag_mode = ""

	elif event is InputEventMouseMotion and _dragging:
		_apply_drag(event.position)
		_canvas.queue_redraw()

func _try_start_drag(mouse: Vector2) -> void:
	# Primero probar handles de la zona seleccionada
	if _selected_zone >= 0 and _selected_zone < _zones.size():
		var r := _zone_to_screen(_zones[_selected_zone]["rect"])
		var handles := {
			"tl": r.position,
			"tr": r.position + Vector2(r.size.x, 0),
			"bl": r.position + Vector2(0, r.size.y),
			"br": r.position + r.size,
		}
		for mode in handles:
			if mouse.distance_to(handles[mode]) <= HANDLE_RADIUS * 2.0:
				_start_drag(mouse, mode)
				return

	# Luego probar click dentro de alguna zona (seleccionar + mover)
	# Prioridad inversa: zonas al final del array están "arriba"
	for i in range(_zones.size() - 1, -1, -1):
		var r := _zone_to_screen(_zones[i]["rect"])
		if r.has_point(mouse):
			_selected_zone = i
			_refresh_zone_list()
			_refresh_mult_panel()
			_start_drag(mouse, "move")
			_canvas.queue_redraw()
			return

func _start_drag(mouse: Vector2, mode: String) -> void:
	_dragging          = true
	_drag_mode         = mode
	_drag_start_mouse  = mouse
	_drag_start_rect   = _zones[_selected_zone]["rect"].duplicate() if _selected_zone >= 0 else Rect2()

func _apply_drag(mouse: Vector2) -> void:
	if _selected_zone < 0 or _selected_zone >= _zones.size():
		return

	var delta_screen := mouse - _drag_start_mouse
	var delta_px     := delta_screen  # 1:1 porque el canvas = tamaño sprite 1:1 en coords normalizadas... no, usamos px
	# Convertir delta de pantalla a px del sprite
	delta_px = delta_screen * (SPRITE_SIZE / _sprite_rect.size)

	var orig := _drag_start_rect
	var r    := orig

	match _drag_mode:
		"move":
			r.position = orig.position + delta_px
		"br":
			r.size = (orig.size + delta_px).max(Vector2(MIN_ZONE_SIZE, MIN_ZONE_SIZE))
		"bl":
			var new_w := orig.size.x - delta_px.x
			if new_w >= MIN_ZONE_SIZE:
				r.position.x = orig.position.x + delta_px.x
				r.size.x     = new_w
			r.size.y = max(orig.size.y + delta_px.y, MIN_ZONE_SIZE)
		"tr":
			var new_h := orig.size.y - delta_px.y
			if new_h >= MIN_ZONE_SIZE:
				r.position.y = orig.position.y + delta_px.y
				r.size.y     = new_h
			r.size.x = max(orig.size.x + delta_px.x, MIN_ZONE_SIZE)
		"tl":
			var new_size := orig.size - delta_px
			if new_size.x >= MIN_ZONE_SIZE and new_size.y >= MIN_ZONE_SIZE:
				r.position = orig.position + delta_px
				r.size     = new_size

	# Clamp dentro del sprite
	r.position = r.position.clamp(Vector2.ZERO, SPRITE_SIZE - r.size)
	r.size     = r.size.clamp(Vector2(MIN_ZONE_SIZE, MIN_ZONE_SIZE), SPRITE_SIZE)
	_zones[_selected_zone]["rect"] = r

# ──────────────────────────────────────────────
#  Coordinadas: px sprite ↔ pantalla
# ──────────────────────────────────────────────
func _zone_to_screen(r: Rect2) -> Rect2:
	var s := _canvas_sprite_rect()
	var scale := s.size / SPRITE_SIZE
	return Rect2(s.position + r.position * scale, r.size * scale)

func _get_corner_positions(screen_rect: Rect2) -> Array:
	return [
		screen_rect.position,
		screen_rect.position + Vector2(screen_rect.size.x, 0),
		screen_rect.position + Vector2(0, screen_rect.size.y),
		screen_rect.position + screen_rect.size,
	]

# ──────────────────────────────────────────────
#  Edición de nombre de zona (doble click)
# ──────────────────────────────────────────────
func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.double_click and mb.button_index == MOUSE_BUTTON_LEFT:
			if _selected_zone >= 0 and _selected_zone < _zones.size():
				_prompt_rename_zone(_selected_zone)

func _prompt_rename_zone(idx: int) -> void:
	# Dialog simple de renombre usando un AcceptDialog con LineEdit
	var dialog := AcceptDialog.new()
	dialog.title = "Renombrar zona"
	var line := LineEdit.new()
	line.text = _zones[idx]["name"]
	line.select_all()
	dialog.add_child(line)
	add_child(dialog)
	dialog.popup_centered(Vector2(300, 80))
	dialog.confirmed.connect(func():
		_zones[idx]["name"] = line.text.strip_edges() if line.text.strip_edges() != "" else _zones[idx]["name"]
		_refresh_zone_list()
		_canvas.queue_redraw()
		_save_current_enemy()
		dialog.queue_free()
	)
	dialog.canceled.connect(func(): dialog.queue_free())
