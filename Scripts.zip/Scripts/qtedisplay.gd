# QTEDisplay.gd
extends Control

const HitboxEditorScript = preload("res://Scripts/hitboxEditor.gd")

signal attack_resolved(shots: Array)

@export var qte_controller: Node
@export var confirm_button: Button
@export var sprite_panel: Control
@export var sprite_node: TextureRect

const PLACEHOLDER_COLOR := Color(0.35, 0.35, 0.45)
const COLOR_LINE_V := Color(1.0, 0.9, 0.2, 0.9)
const COLOR_LINE_H := Color(0.2, 0.95, 1.0, 0.9)
const COLOR_HIT := Color(1.0, 0.4, 0.1)
const COLOR_MISS := Color(0.55, 0.55, 0.55)

var _sprite_rect: Rect2          
var _line_v: float = 0.0         
var _line_h: float = 0.0
var _phase: String = "idle"      

var _shots_pending: int = 0
var _bullet_damage: float = 0.0
var _player: Object = null
var _elipse: Object = null
var _resolved: Array = []
var _shot_calc_data: Array = []
var _current_enemy_data: Dictionary = {}
var _debug_mode: bool = false

var debug_overlay: Control = null

func _ready() -> void:
	add_to_group("center_display")
	mouse_filter = Control.MOUSE_FILTER_STOP
	
	debug_overlay = Control.new()
	debug_overlay.name = "DebugOverlay"
	debug_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	debug_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(debug_overlay)
	debug_overlay.draw.connect(_on_debug_overlay_draw)
	
	if confirm_button:
		confirm_button.pressed.connect(_on_confirm_pressed)
	
	if qte_controller:
		qte_controller.axis_changed.connect(_on_axis_changed)
		qte_controller.qte_completed.connect(_on_qte_completed)
	
	hide()

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F1:
			_debug_mode = not _debug_mode
			queue_redraw()
			if debug_overlay:
				debug_overlay.queue_redraw()

func _init_elipse() -> void:
	if _elipse == null:
		_elipse = load("res://Scripts/elipse_calculator.gd").new()

func set_enemy(enemy_data: Dictionary) -> void:
	_current_enemy_data = enemy_data

func start_qte(player: Object, bullets: int, _sprite_texture: Texture2D = null) -> void:
	print("[QTEDisplay] start_qte - player: ", player.character_name, " bullets: ", bullets)
	
	_player = player
	_shots_pending = bullets
	_bullet_damage = player.damage
	_resolved.clear()
	_shot_calc_data.clear()
	_phase = "vertical"
	_line_v = 0.5
	_line_h = 1.0 if player.left_handed else 0.0

	if sprite_node:
		sprite_node.texture = null

	_update_sprite_rect()
	_init_elipse()
	_elipse.setup(0.0, 0.0, 1.0, 1.0, 1.0)

	show()
	queue_redraw()
	
	if confirm_button:
		confirm_button.text = "Confirmar"
		confirm_button.disabled = false
		confirm_button.show()
	
	if qte_controller:
		qte_controller.start(player)

func _update_sprite_rect() -> void:
	var viewport_size = get_viewport().get_visible_rect().size
	
	if sprite_panel and sprite_panel.is_inside_tree() and sprite_panel.size.x > 1:
		var local_pos = sprite_panel.global_position - global_position if is_inside_tree() else sprite_panel.position
		_sprite_rect = Rect2(local_pos, sprite_panel.size)
	elif sprite_node and sprite_node.is_inside_tree() and sprite_node.size.x > 1:
		var local_pos = sprite_node.global_position - global_position if is_inside_tree() else sprite_node.position
		_sprite_rect = Rect2(local_pos, sprite_node.size)
	else:
		var desired_width = min(300.0, viewport_size.x * 0.35)
		var desired_height = desired_width * 1.75
		var fallback = Vector2(desired_width, desired_height)
		_sprite_rect = Rect2(viewport_size / 2 - fallback / 2, fallback)

func _process(delta: float) -> void:
	if not visible:
		return
	
	if qte_controller and qte_controller.is_active():
		qte_controller.tick(delta)
		queue_redraw()

func _on_axis_changed(axis: String, value: float) -> void:
	if axis == "vertical":
		_line_v = value
		_phase = "vertical"
	else:
		_line_h = value
		_phase = "horizontal"
	queue_redraw()

func _on_confirm_pressed() -> void:
	if _phase == "done":
		hide()
		emit_signal("attack_resolved", _resolved)
		return
	
	if qte_controller:
		qte_controller.register_input()

func _on_qte_completed(point: Vector2) -> void:
	print("[QTEDisplay] qte_completed - point: ", point)
	_phase = "done"
	_line_h = point.x
	_line_v = point.y

	var first = _resolve_shot(point)
	_resolved.append(first)
	_shot_calc_data.append({
		"u": -1.0, "v": -1.0, "q": -1.0, "w": -1.0,
		"rx": 0.0, "ry": 0.0,
		"n": point.x, "m": point.y,
		"h": 0.0, "k": 0.0, "r": 0.0, "a": 0.0, "b": 0.0,
		"point": point,
		"previous_point": Vector2.ZERO,
		"manual": true,
	})

	var previous_point = point
	for i in range(1, _shots_pending):
		var shot_set: Dictionary = _player.call("get_elipse_set", i)
		var offset_x = float(shot_set.get("h", 0.5)) - 0.5
		var offset_y = float(shot_set.get("k", 0.5)) - 0.5
		_elipse.h = previous_point.x + offset_x
		_elipse.k = point.y + offset_y
		_elipse.r = float(shot_set.get("r", 0.05))
		_elipse.a = float(shot_set.get("a", 1.0))
		_elipse.b = float(shot_set.get("b", 1.0))
		var calc: Dictionary = _elipse.next_point_from_verbose(previous_point)
		var ep: Vector2 = (calc["point"] as Vector2).clamp(Vector2.ZERO, Vector2.ONE)

		calc["point"] = ep
		calc["previous_point"] = previous_point
		_shot_calc_data.append(calc)

		_resolved.append(_resolve_shot(ep))
		previous_point = ep

	queue_redraw()
	if debug_overlay:
		debug_overlay.queue_redraw()
	
	if confirm_button:
		confirm_button.text = "Continuar"
		confirm_button.disabled = false
		confirm_button.show()

func _resolve_shot(point: Vector2, _player_unused = null) -> Dictionary:
	var zone: String = "Torso"
	var mult: float = 1.0
	var inside_silhouette: bool = true
	var enemy_data: Dictionary = _current_enemy_data

	if enemy_data.has("grid_cells") and enemy_data.has("grid_zones") \
			and not enemy_data["grid_cells"].is_empty() and not enemy_data["grid_zones"].is_empty():
		var zone_result: Dictionary = HitboxEditorScript.get_zone_at(point, enemy_data)
		zone = zone_result.get("name", "Sin zona")
		mult = float(zone_result.get("mult", 0.0))
		if zone == "Sin zona" or (mult == 0.0 and zone_result.get("name", "") == "Sin zona"):
			inside_silhouette = false
	else:
		if point.y <= 0.20:
			zone = "Cabeza"
			mult = 2.0
		elif point.y <= 0.60:
			zone = "Torso"
			mult = 1.0
		else:
			zone = "Piernas"
			mult = 0.6
	
	var hit = inside_silhouette
	var damage = _bullet_damage * mult if hit else 0.0

	return {
		"point": point,
		"zone": zone,
		"hit": hit,
		"inside_silhouette": inside_silhouette,
		"damage": damage,
		"mult": mult,
	}

func _draw() -> void:
	_update_sprite_rect()
	var s = _sprite_rect
	var font = ThemeDB.fallback_font

	var instruction = ""
	match _phase:
		"vertical":   instruction = "↕  Presioná CONFIRMAR para fijar la mira vertical"
		"horizontal": instruction = "↔  Presioná CONFIRMAR para fijar la mira horizontal"
		"done":       instruction = "Impactos resueltos"
	
	draw_string(font, Vector2(s.position.x, s.position.y - 28),
		instruction, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color.WHITE)
	
	if sprite_node and sprite_node.texture == null:
		draw_rect(s, PLACEHOLDER_COLOR)
		draw_string(font, s.position + Vector2(8, 20),
			"[sprite enemigo]", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(0.7, 0.7, 0.7))
	
	draw_rect(s, Color.WHITE, false, 1.5)
	
	if _phase == "vertical" or _phase == "done":
		var ly = s.position.y + _line_v * s.size.y
		draw_line(Vector2(s.position.x, ly), Vector2(s.position.x + s.size.x, ly),
			COLOR_LINE_V, 2.0)
	
	if _phase == "horizontal" or _phase == "done":
		var lx = s.position.x + _line_h * s.size.x
		draw_line(Vector2(lx, s.position.y), Vector2(lx, s.position.y + s.size.y),
			COLOR_LINE_H, 2.0)
	
	for i in _resolved.size():
		var shot: Dictionary = _resolved[i]
		var pt: Vector2 = shot["point"]
		var px = s.position.x + pt.x * s.size.x
		var py = s.position.y + pt.y * s.size.y
		var col = COLOR_HIT if shot["hit"] else COLOR_MISS
		var radius = max(4.0, s.size.x * 0.02)

		draw_circle(Vector2(px, py), radius, col)
		draw_circle(Vector2(px, py), radius, Color.WHITE, false, 1.5)

		var label = "%s  %.0f dmg" % [shot["zone"], shot["damage"]] if shot["hit"] else "FALLO"
		var font_size = max(10, int(s.size.x * 0.035))
		draw_string(font, Vector2(px + 8, py + 4), label,
			HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)

func _on_debug_overlay_draw() -> void:
	if not _debug_mode:
		return
	
	_update_sprite_rect()
	
	debug_overlay.draw_rect(Rect2(Vector2.ZERO, debug_overlay.size), Color(0.2, 0.1, 0.3, 0.3))
	
	var s = _sprite_rect
	if s.size.x <= 0 or s.size.y <= 0:
		return
	
	debug_overlay.draw_rect(s, Color(1.0, 0.5, 0.0, 0.5), false, 2.0)
	
	var enemy_data: Dictionary = _current_enemy_data
	var has_grid = enemy_data.has("grid_cells") and enemy_data.has("grid_zones")
	
	if has_grid:
		var cells = enemy_data["grid_cells"]
		var zones = enemy_data["grid_zones"]
		if not cells.is_empty() and not zones.is_empty():
			var cols = 10
			var rows = 15
			var cell_w = s.size.x / cols
			var cell_h = s.size.y / rows
			
			for r in rows:
				for c in cols:
					var i = r * cols + c
					var cell_rect = Rect2(
						s.position + Vector2(c * cell_w, r * cell_h),
						Vector2(cell_w, cell_h)
					)
					var zone_idx = int(cells[i]) if i < cells.size() else -1
					if zone_idx >= 0 and zone_idx < zones.size():
						var z = zones[zone_idx]
						var fill_col = Color(z.get("cr", 0.5), z.get("cg", 0.5), z.get("cb", 0.5), 0.35)
						debug_overlay.draw_rect(cell_rect, fill_col)
						debug_overlay.draw_rect(cell_rect, Color(1, 1, 1, 0.5), false, 1.0)
					else:
						debug_overlay.draw_rect(cell_rect, Color(1, 1, 1, 0.08), false, 0.5)
			
			var font = ThemeDB.fallback_font
			var zone_labeled = {}
			for i in cells.size():
				var zone_idx = int(cells[i])
				if zone_idx < 0 or zone_idx >= zones.size():
					continue
				if zone_labeled.has(zone_idx):
					continue
				zone_labeled[zone_idx] = true
				var r = i / cols
				var c = i % cols
				var z = zones[zone_idx]
				var label_pos = s.position + Vector2(c * cell_w + 2, r * cell_h + 12)
				debug_overlay.draw_string(font, label_pos,
					"%s x%.1f" % [z.get("name", "?"), z.get("mult", 1.0)],
					HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color.WHITE)
	
	if _player != null and _shot_calc_data.size() > 0:
		_draw_elipses_debug(s)
	
	var font = ThemeDB.fallback_font
	debug_overlay.draw_string(font, Vector2(10, 20),
		"DEBUG MODE ACTIVADO - F1 para ocultar",
		HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.YELLOW)

func _draw_ellipse_outline(center: Vector2, rx: float, ry: float, col: Color) -> void:
	if rx <= 0 or ry <= 0:
		return
	
	var pts = PackedVector2Array()
	var segments = 48
	
	for seg in segments + 1:
		var angle = 2.0 * PI * float(seg) / float(segments)
		var x = center.x + cos(angle) * rx
		var y = center.y + sin(angle) * ry
		pts.append(Vector2(x, y))
	
	debug_overlay.draw_polyline(pts, col, 2.0, true)

func _draw_center_cross(center: Vector2, col: Color) -> void:
	var cross_size = 6.0
	debug_overlay.draw_line(
		center + Vector2(-cross_size, 0), center + Vector2(cross_size, 0),
		col, 1.5)
	debug_overlay.draw_line(
		center + Vector2(0, -cross_size), center + Vector2(0, cross_size),
		col, 1.5)

func _draw_elipses_debug(sprite_rect: Rect2) -> void:
	var colors = [
		Color(1.0, 0.2, 0.2, 0.9),
		Color(0.2, 1.0, 0.2, 0.9),
		Color(0.2, 0.5, 1.0, 0.9),
		Color(1.0, 0.9, 0.2, 0.9),
		Color(1.0, 0.4, 1.0, 0.9),
		Color(0.4, 1.0, 1.0, 0.9),
	]
	var font = ThemeDB.fallback_font
	
	for i in _shot_calc_data.size():
		var calc: Dictionary = _shot_calc_data[i]
		var col: Color = colors[i % colors.size()]

		var point_px = sprite_rect.position + Vector2(
			calc["point"].x * sprite_rect.size.x,
			calc["point"].y * sprite_rect.size.y
		)
		
		if calc.get("manual", false):
			debug_overlay.draw_circle(point_px, 5.0, col)
			debug_overlay.draw_string(font, point_px + Vector2(8, -8),
				"#1 (manual)",
				HORIZONTAL_ALIGNMENT_LEFT, -1, 11, col)
			continue
		
		var center_norm = Vector2(calc.get("h", 0.5), calc.get("k", 0.5))
		var center_px = sprite_rect.position + Vector2(
			center_norm.x * sprite_rect.size.x,
			center_norm.y * sprite_rect.size.y
		)
		
		var rx_px = calc.get("rx", 0.05) * sprite_rect.size.x
		var ry_px = calc.get("ry", 0.05) * sprite_rect.size.y
		
		_draw_ellipse_outline(center_px, rx_px, ry_px, col)
		_draw_center_cross(center_px, col)
		
		debug_overlay.draw_line(center_px, point_px, col, 1.5)
		debug_overlay.draw_circle(point_px, 5.0, col)
		
		debug_overlay.draw_string(font, center_px + Vector2(6, -6),
			"#%d" % (i + 1),
			HORIZONTAL_ALIGNMENT_LEFT, -1, 12, col)
